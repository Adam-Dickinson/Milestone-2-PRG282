USE Milestone2PRG_282

GO

CREATE PROCEDURE spGetStudents

AS
BEGIN
	SELECT * FROM StudentInfo
END